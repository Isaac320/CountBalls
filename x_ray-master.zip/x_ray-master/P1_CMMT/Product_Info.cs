﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P1_CMMT
{
    public class Product_Info
    {
        public double score;
        public double mean;
        public double deviation;
        public double Contrast;
    }
}
