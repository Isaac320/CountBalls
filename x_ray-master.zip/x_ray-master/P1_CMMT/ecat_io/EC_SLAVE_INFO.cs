﻿namespace ecat_io
{
    internal class EC_SLAVE_INFO
    {
    }
}